package assisted;
import java.util.ArrayList;
public class Collections {
	
		    public static void main(String[] args){
		        ArrayList<String> edibles = new ArrayList<>();
		        edibles.add("vegetable");
		        edibles.add("fruit");
		        edibles.add("flowers");

		        System.out.println("ArrayList: " + edibles);
		    	}
}

package assisted;

public class CallMethod{
	
	//void method do not have any return type
	 public void methodDisplay() {
		System.out.println("Display method called");
	 }
	 
	 public int methodNumber() {
		 
		 int a=5;
		 return a;
	 }
	
	 public static void main(String[] args) {
		 
		 CallMethod obj= new CallMethod();
		 obj.methodDisplay();
		 
		 int result=obj.methodNumber();
		 
		 System.out.println(result);
		
	}
}

